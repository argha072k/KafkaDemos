package com.example.newcode.kafka;


import com.example.newcode.models.PlayerInfo;
import com.example.newcode.models.PlayerStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class DemoProducer {

    private static final Logger LOGGER= LoggerFactory.getLogger(DemoProducer.class);

    private KafkaTemplate kafkaTemplate ;

    public DemoProducer(KafkaTemplate kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendmsgtoTopicA(PlayerInfo playerinfo){
        LOGGER.info((String.format("msg sent to topic Information %s ",playerinfo.toString())));
        kafkaTemplate.send("Information",3,null,playerinfo);
    }

    public void sendmsgtoTopicB(PlayerStats playerStats){
        LOGGER.info((String.format("msg sent to topic Statistics %s",playerStats.toString())));
        kafkaTemplate.send("Statistics",playerStats);
    }
}
