package com.example.newcode.Config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;


@Configuration
public class TopicConfig {

    @Bean
    public NewTopic java1topic(){
        return TopicBuilder
                .name("Information")
                .partitions(4)
                .build();
    }

    @Bean
    public NewTopic java2topic(){
        return TopicBuilder
                .name("Statistics")
                .partitions(2)
                .build();
    }

}
