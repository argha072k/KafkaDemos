package com.example.newcode.cont;


import com.example.newcode.kafka.DemoConsumer;
import com.example.newcode.kafka.DemoProducer;
import com.example.newcode.models.PlayerInfo;
import com.example.newcode.models.PlayerStats;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class controller {

    private DemoProducer demoProducer;

    public controller(DemoProducer demoProducer) {
        this.demoProducer = demoProducer;
    }

    @PostMapping("/info")
    public ResponseEntity<String>publishToA(@RequestBody PlayerInfo playerinfo){
        demoProducer.sendmsgtoTopicA(playerinfo);
        return new ResponseEntity<>("msg successfuly sent to topic Information", HttpStatus.OK);
    }

    @PostMapping("/stats")
    public ResponseEntity<String>publishToB(@RequestBody PlayerStats playerStats){
        demoProducer.sendmsgtoTopicB(playerStats);
        return new ResponseEntity<>("msg successfuly sent to topic Statistics", HttpStatus.OK);
    }
}
