package com.example.newcode.kafka;


import com.example.newcode.models.PlayerInfo;
import com.example.newcode.models.PlayerStats;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Service;



@Service
public class DemoConsumer {

    private static final Logger LOGGER= LoggerFactory.getLogger(DemoConsumer.class);

    @KafkaListener(topics = "Information",groupId = "players1")
    public void receivemsgfromTopicA(ConsumerRecord<String,PlayerInfo>record){
        LOGGER.info(("msg received from topic Information -> " + record.value() + " from partition " + record.partition() + " committed offset " + record.offset()));
    }

    @KafkaListener(topics = "Statistics",groupId = "players2")
    public void receivemsgfromTopicB(ConsumerRecord<String,PlayerStats>record){
        LOGGER.info(("msg received from topic Statistics -> " + record.value()+ " from partition " + record.partition() + " committed offset " + record.offset()));
    }

//    @KafkaListener(topics = {"Information","Statistics"},groupId = "players1")
//    public void receiveall(ConsumerRecord<String,PlayerInfo>record){
//        LOGGER.info((String.format("msg received from partition %d of topic %s with key= %s and msg value = %s ",record.partition(),record.topic(),record.key(),record.value())));
//    }
}
